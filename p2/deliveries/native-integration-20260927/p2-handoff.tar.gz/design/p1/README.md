# P1 执行记录：合仓与统一构建

2026-09-27 P2 交付更新：原生化源码及本机检查已完成，完整交接见 [P2](../p2/README.md)。内网构建、功能与性能统一验证待用户执行，P1 复测/已知问题修复仍后置。

状态：已按用户最新授权启动，首批源码改造及本机检查已完成；**内网构建、安装与运行等价验收未完成，P1 尚未通过出口**。

2026-09-27 更新：新增基线/P1 日志确认两包 strict editable 服务实际运行，也暴露共同的缓存异常恢复与压测统计问题；详见 [日志评估](results/log-review-20260927/README.md)。用户随后明确要求保留 P1 并启动 P2，复测和问题修复后置。两仓已建立保留分支 `p1`，当前目录检出的是 `p2`，见 [P2 执行记录](../p2/README.md)。本文及历史审计工具仍描述 P1；不要把 P2 工作树套入要求 donor 文件逐字一致、版本为 P1 的历史检查。

本轮允许在其他开发人员验证基线、后续归档数据期间推进 P1 源码工作。这是明确的阶段启动授权，不代表 P0/NPU 验收已经通过，也不授权替换现有服务。

2026-09-23 pip 检查补充：按用户明确授权，只豁免 `op-compile-tool 0.1.0` 对 getopt、inspect、multiprocessing 的三条标准库误声明。[只读 pip 检查工具](tools/check_pip_dependencies.py) 保留完整原始输出/退出码，并单列豁免后的判断；其他缺依赖、版本冲突和未知诊断仍会停止。已接入安装前后及构建前检查，命令见[内网指导第 3.2 节](intranet-next-steps.md#32-已批准的-pip-标准库误声明豁免)。本次仅修改 design/p1，不改两仓源码和提交。

本次 41 项约束测试（含新增 10 项精确豁免回归）通过，记录见[pip 豁免验证](results/pip-stdlib-waiver-20260923/README.md)。

2026-09-23 候选更新：按用户最新内网预检反馈，统一接受 `torch-npu==2.9.0.post2`、`transformers==5.2.0`；torch 本体仍为 2.9.0，其他候选不变。同步修改两仓运行/构建声明、原生构建校验与 profile，preflight 继续按选定源码声明严格核验，不跳过不匹配。当前配对提交及重试方法见[内网指导](intranet-next-steps.md)，累计清单改用 `baseline/p1-intranet-candidates-20260923.json`。历史记录保留，不能把元数据通过视作 Transformers 5/ABI 兼容性证明。

本次候选调整的 75 项轻量测试与源码审计已通过，原生/内网验证待执行；证据见[候选同步记录](results/intranet-candidates-20260923/README.md)。

此前同日开发安装批次：两个 P1 仓已各自携带 `p1_dev.py`，支持材料核验、依赖检查、wheel 构建/安装、strict editable 调测和安装路径检查。每次原生编译使用新的保留目录，不复用旧 ACLNN 或已链接的设备对象。具体命令见[开发调测指南](development-build-install.md)，正式验收见[内网主流程](intranet-next-steps.md)。本机未编译/安装，不代表已可在 NPU 运行。该批历史清单为 `baseline/p1-build-install-20260923.json`；当前配对 SHA 和清单以上文最新候选更新及主流程为准。

此前同日修复批次：四仓 `fix/staged-sfa-event-handoff` 已合入本地基线，并移植到 P1 的 vllm `3827b16205a3b748629e38ad739dfc55c6b04d49`、LMCache `b5a9db3577d28097f9051ea7b9f6ef68fb11b8eb`；当前开发安装改动叠加在这两个提交之上，未改动原四仓。详见[修复合入记录](staged-sfa-event-handoff-integration.md)。历史清单、该批 25 项修复清单及 source-01 报告均保留，不改写为新批次结果。

## 1. 当前生效范围

以 [profile.json](profile.json) 为本轮机器可读配置：

- 仅 GLM-5.2 原生文本生成；GLM-5.3 后续扩展。
- DSA 双组开启（UNBUNDLE 与 TWO_GROUPS 均开启），MTP 开启；现有启动片段为单 token MTP，交接时记录最终有效值。
- C8 关闭。权重目录仍叫 GLM-5.2-w4a8c8，不修改权重或量化元数据；目录标签、W4A8 权重量化、运行时 KV/index cache dtype 分别核实。
- 同时验收 TP8/DP2 和 TP4/DP4，均为 4 节点 × 8 张 910B3、物理 2P2D。前者每节点一个 TP8 实例，P/D 各 DP2；后者每节点两个 TP4 实例，P/D 各 DP4，不重复计算卡数。
- 保留离线、在线、CPU KV 卸载、跨实例缓存、P/D、checkpoint、RemoteFill 及恢复能力。
- 复用 CANN 8.5.1、torch 2.9.0+cpu、torch_npu 2.9.0.post2、Transformers 5.2.0、triton-ascend 3.2.0.dev20260322，候选版本不等于 ABI/功能认证。

## 2. 已实施的源码变更

P1 源码保留在工作区根目录 `p1-repos/` 两个独立仓的 `p1` 分支：vLLM 为 `230fbc0218e656cb90f8a8c2261150345a1d8ee5`，LMCache 为 `547ae7c10b0e510b864c8d0f5233d6f54f279359`；原 `main` 也保持这些提交。当前工作树已切换到 `p2`。`origin` 分别指向新的 `vllm-dual` / `LMCache-dual` 仓库。初始导入使用的 `p1-worktrees/` 已在核对提交、文件树和额外文件后移除，不再作为开发入口。原始四个 checkout、原重构分支和备份继续保留；本次 P2 启动未修改原仓、推送远端、停止服务或执行安装。历史迁移见 [工作区迁移记录](workspace-migration.md)。

| P1 仓库 | 唯一 distribution | 暂时保留的 Python namespace |
| --- | --- | --- |
| [vllm](../../p1-repos/vllm/) | vllm 0.18.0+ascend.p1 | vllm、vllm_ascend |
| [LMCache](../../p1-repos/LMCache/) | lmcache 0.4.3+ascend.p1 | lmcache、lmcache_ascend |

版本号是 P1 内部交付标识，不表示升级到了另一个上游主分支；初始来源见下表，当前版本还叠加本批记录的修复。Ascend namespace 源码位于各仓 `ascend/` 下，通过唯一根构建入口映射到 wheel 顶层。不需要再安装两个 Ascend distribution。

1. 导入当前 Ascend 快照、测试、原生源码及许可证；逐文件路径映射见 [source-manifest.json](baseline/source-manifest.json)。插件旧 setup/pyproject 改名归档到 `ascend/upstream-build/`，不再是活动入口。
2. 每仓只有一个根 setup/pyproject/CMake 入口；保留 Ascend 算子、包资源、版本信息和 vLLM 的 Ascend entry points。P1 仍有临时插件发现和运行时 patch，原生化在 P2/P3 完成。
3. 构建依赖固定到候选 torch/NPU 版本；运行依赖统一为 `requirements/ascend.txt`，不再选择 CPU/CUDA/HIP 构建或下载上游预编译 wheel。旧 `requirements/common.txt` 等保留作后续裁剪依据，不能继续作为本轮安装入口。
4. LMCache 同时构建 Ascend c_ops/cache kernels、HIXL/hcomm 及 host native_storage_ops/fs/redis。可选 native Mooncake 保留显式构建开关；它与 RemoteFill 使用的 CANN Python Mooncake 不是一回事。
5. 原生构建仅接受明确的 910B3、Python 3.11/aarch64 和 CANN 8.5.1。自定义算子在新建的私有源码副本中生成，缺子模块直接失败，不修改 Git 全局配置、不在构建阶段自动下载。
6. 校验并复用内网已初始化的固定子模块，生成逐文件材料哈希；从普通源码包或 sdist 重建不依赖 .git。
7. 迁移 host 测试相对路径，保留原断言；建立新构建/交付约束测试及 wheel 内容检查。
8. 提供两个独立的开发安装入口；strict editable 映射两个 namespace、全部 native 文件和 CANN 资源到保留的构建目录。vLLM custom-op 定位改为保留链接目录，避免返回原始源码树丢失资源；普通 wheel 路径行为保持。新增 44 项轻量测试覆盖材料、安装保护、干净编译、产物映射、日志及资源路径。

2026-09-23 追加事件交接、GLM router、调度/恢复和缓存修复，共 10 个生产文件和 15 个测试文件；生产代码与合入后的原仓逐文件一致，不属于新一轮算法重写。尚未执行：删除其他模型/设备源码、去除临时 namespace、安装后替换现有服务。多模态及其他模型的传递依赖暂时保留，须在 P4 拆解导入闭包后裁剪；当前不能宣称已是最终极简框架。

## 3. 输入与备份

| 原仓 | 初始 source-01 输入 HEAD（非本批修复后 HEAD） |
| --- | --- |
| vllm | `ded5ce2a5388e1abb799d9b099849f3bd4a72360` |
| vllm-ascend | `d22f0b7cffde1b6ddb87cb44368e46193e811cc9` |
| LMCache | `802e4167afa75c1601b9f9d8619672a686b416bd` |
| LMCache-Ascend | `d959c7a9640681e414dc9dbca644627af67a51e8` |

上述提交包含 P0 独立修复，与最初设计调研 HEAD 不同。四个 bundle 保存在 `baseline/*.bundle`（Git 忽略的大文件），已执行 bundle verify；其 commit/tree/SHA-256 及来源映射记录在清单中。`source-01` 归档制作时尚未创建 P1 提交；其后 P1 改动已提交，并于 2026-09-21 推送到下面两个新仓。不能将原四仓输入 HEAD 当作改造后的交付版本。

| 新仓（`main`） | 初次发布的 P1 提交（非当前本地 HEAD） |
| --- | --- |
| [vllm-dual](https://github.com/zhangzhaoju/vllm-dual) | `b2025e53890eb9b65db3cfacba8e0237bea9654d` |
| [LMCache-dual](https://github.com/zhangzhaoju/LMCache-dual) | `5b09009c5264cb61d204b7660ae400b4392db46a` |

两个新仓当前为公开仓，GitHub Actions 按用户选择保持开启；GitHub 工作流结果不替代内网验收。`design` 文档及内网报告没有随两个代码仓推送。

Git 快照未包含被 `.claude/` 忽略规则排除的 `vllm/ascend/.claude/README.md`（非运行时说明）。删除旧 worktree 前已将其逐字保留到 `p1-repos`，与原 donor 文件哈希一致；它仍未进入 Git。内网首次 Git clone 后须按 [内网步骤](intranet-next-steps.md) 从固定 donor 提交恢复，再做严格源码审计；不得忽略缺失项或修改历史来源清单来绕过检查。`source-01` 普通归档已包含该文件。

本机缺 CATLASS 和 kvcache-ops 载荷，只有固定 gitlink。内网旧仓已有相应提交，可使用 [materialize_submodules.py](tools/materialize_submodules.py) 复制已核实的源码；不得声称本机普通归档已经包含完整构建材料。

## 4. 检查结果及局限

开发安装批次的本机检查：44 项新增测试、24 项交付约束、5 项 CMake 入口、55 项 SFA 回归通过，共 128 项；native 命令均为模拟，不包含真实编译或 pip 安装。完整记录及限定见 [build-install-20260923](results/build-install-20260923/README.md)。本机 setuptools 为 68.1.2，不是目标 77.0.3～80.x；目标环境仍须执行 PEP 660、sdist/wheel、ABI/NPU 实测。新 RST 页独立 Sphinx 检查通过，全站因缺 `sphinxawesome_theme` 未完成。

本批另行复测 host 子集为 107/112，通过数不计入上述 128 项；5 个失败均为本机缺少 torch，0 skip。仍要求内网 112/112，详见[新 host 报告](results/build-install-20260923/host/summary.json)。

下表及 `results/validation-summary.json` 记录初始 `source-01` 批次，保留当时的 worktree 路径和“尚未创建提交”状态，不能当作当前工作区定位。目录移除后的复核单列在 [迁移记录](workspace-migration.md)，不改写旧 host/交付报告。

| 检查 | 本轮结果 |
| --- | --- |
| 新构建/交付约束单元测试 | 17/17 通过；只测试元数据、计划与合成 ZIP，不调用 build backend |
| 生产源码 AST | 两仓共 2239 个 Python 文件解析通过 |
| 快照保持检查 | 无生产 Python 改写、无丢失 donor 文件；差异为构建及测试路径适配 |
| 迁移 host 子集 | 107/112 通过，5 个失败均因本机没有 torch；0 skip |
| 原仓对照 | 同一 LMCache-Ascend 子集也为 21 通过/5 个缺 torch 失败 |
| 已归档 P0 内网 host | 112/112 通过；这是原四仓结果，不冒充 P1 通过 |
| sdist/wheel/native/NPU | 本机未执行；全部待内网 |

证据：[源码审计](results/source-audit-01.json)、[约束测试](results/contracts-01.log)、[迁移后 host](results/host-local-01/summary.json)、[原仓对照](results/host-original-control-01/summary.json)。普通交付包解包后也通过 [源码审计](results/export-audit-01.json) 和 [17 项约束测试](results/export-contracts-01.log)；这不是 sdist/wheel 构建测试。

已生成 [source-01 交付目录](deliveries/source-01/)，其中两份普通源码归档约 36 MiB / 4.3 MiB，SHA256SUMS 核对通过；仍需内网补齐固定子模块。汇总见 [检查记录](results/validation-summary.json)。后续批次保留新目录，不覆盖本批或 P0 报告。

当前约束测试默认读取 `p1-repos/`；内网或临时解包目录使用 `P1_SOURCE_WORKSPACE` 覆盖。审计、普通源码导出和 host 检查均显式传入 `--workspace p1-repos`。`tools/prepare_worktrees.py` 仅保留作初始导入与来源清单的历史实现，不是日常恢复/准备命令。

## 5. 下一步与出口

执行顺序及可复制命令见 [内网接力说明](intranet-next-steps.md)；日常调测另见 [编译安装指南](development-build-install.md)。先同步最新配对提交与 design 工具，再做源码审计、材料校验、依赖预检及回归；无需停止现有 GLM 服务。实际编译、安装及 NPU 测试使用隔离环境和预约资源。editable 的首次编译和安装成功不等于 P1 验收通过。

P1 出口仍须逐项取得：

- 两仓 wheel 和 sdist 重新展开后的构建、内容检查、扩展加载及 ABI 结果。
- 干净验证容器仅安装两个 distribution；无旧 editable、PYTHONPATH 或原始四仓导入污染。
- 其他开发人员归档两种并行布局的有效 DSA 双组/MTP/C8-off 配置与基线数据。
- 相同输入、权重、采样和拓扑下，P1 离线/在线/缓存/恢复及性能与对应基线对照通过。

未完成这些项目时，保留原四仓与服务，不推进依赖运行等价证明的大规模裁剪，不宣告 P1 完成。
